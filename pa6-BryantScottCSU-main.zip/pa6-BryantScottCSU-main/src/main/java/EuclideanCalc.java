import java.util.ArrayList;
import java.util.Map;

import org.apache.commons.math4.legacy.ml.distance.EuclideanDistance;

public class EuclideanCalc {
    /**
     * 
     * @param x
     * @param y
     * @return
     */
    public static double calculateDistance(User x, User y) {
        ArrayList<Song> songsInCommon = getSongsInCommon(x, y);
        if(songsInCommon.size() < 1) {
            x.getSimilarityMap().put(y, Double.NaN);
            y.getSimilarityMap().put(x, Double.NaN);
            return Double.NaN;
        }
        double[] userxScoresArray = getArray(x, songsInCommon);
        double[] useryScoresArray = getArray(y, songsInCommon);

        double distance = calculateDistance(userxScoresArray, useryScoresArray);
        x.getSimilarityMap().put(y, distance);
        y.getSimilarityMap().put(x, distance);
        return distance;
    }
/**
 * 
 * @param user1
 * @param user2
 * @return
 */
    private static ArrayList<Song> getSongsInCommon(User user1, User user2) {
        ArrayList<Song> songsList = new ArrayList<>(user1.getZScoreMap().keySet());
        ArrayList<Song> songsInCommon = new ArrayList<>();
        for(Song song : songsList) {
            if(user1.getZScoreMap().containsKey(song) && user2.getZScoreMap().containsKey(song)){
                songsInCommon.add(song);
            }
        }
        return songsInCommon;
    }
/**
 * 
 * @param x
 * @param y
 * @return
 */
    public static double calculateDistance(Song x, Song y) {
      ArrayList<User> usersInCommon = getUsersInCommon(x, y);

        double[] songxScoresArray = getArray(x, usersInCommon);
        double[] songyScoresArray = getArray(y, usersInCommon);

        double distance = calculateDistance(songxScoresArray, songyScoresArray);

        return distance;
 
    }
/**
 * 
 * @param song1
 * @param song2
 * @return
 */
    private static ArrayList<User> getUsersInCommon(Song song1, Song song2) {

        ArrayList<String> userNames = ListsRepository.getInstance().getUserList();
        Map<User, Double> song1ScoresMap = SongRepository.getInstance().getSongByName(song1.getName()).getZScoreMap();
        Map<User, Double> song2ScoresMap = SongRepository.getInstance().getSongByName(song2.getName()).getZScoreMap();
        ArrayList<User> usersInCommon = new ArrayList<>();

        for(String userName : userNames) {
            User user = UserRepository.getInstance().getUserByName(userName);
            if(song1ScoresMap.containsKey(user) && song2ScoresMap.containsKey(user)){
                usersInCommon.add(user);
            }
        }
        return usersInCommon;
    }
/**
 * 
 * @param x
 * @param y
 * @return
 */
    public static double calculateDistance(double[] x, double[] y) {
        EuclideanDistance euclideanDistance = new EuclideanDistance();
        return euclideanDistance.compute(x, y);
    }

    private static double[] getArray(User x, ArrayList<Song> songsInCommon) {

        double[] toReturn = new double[songsInCommon.size()];
        Map<Song, Double> userScoresMap = UserRepository.getInstance().getUserByName(x.getName()).getZScoreMap();
        for(int i = 0; i < songsInCommon.size(); i++) {
            if(!x.getZScoreMap().get(songsInCommon.get(i)).equals(Double.NaN)) {
            toReturn[i] = userScoresMap.get(songsInCommon.get(i));
            }
        }
        return toReturn;
    }
/**
 * 
 * @param x
 * @param usersInCommon
 * @return
 */
    private static double[] getArray(Song x, ArrayList<User> usersInCommon) {
        double[] toReturn = new double[usersInCommon.size()];
         Map<User, Double> songScoresMap = SongRepository.getInstance().getSongByName(x.getName()).getZScoreMap();
        for(int i = 0; i < usersInCommon.size(); i++) {
            toReturn[i] = songScoresMap.get(usersInCommon.get(i));
        }
        return toReturn;
    }
/**
 * 
 * @param x
 * @return
 */
    public static double[] getArray(Song x) {
        Map<User, Double> predictedRatingsNormalMap = x.getPredictedRatingsNormalMap();
        double[] toReturn = new double[predictedRatingsNormalMap.size()];
        int i = 0;
        
        for(User user : predictedRatingsNormalMap.keySet()) {
            toReturn[i] = predictedRatingsNormalMap.get(user);
            i++;
        }

        return toReturn;
    }
}
