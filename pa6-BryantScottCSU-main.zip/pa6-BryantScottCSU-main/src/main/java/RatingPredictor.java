import java.util.ArrayList;
import java.util.Map;

public class RatingPredictor {
    
    public static void predictRatings(String pathFlag) throws Exception{
        
        ArrayList<String> userList = ListsRepository.getInstance().getUserList();
        ArrayList<String> songList = ListsRepository.getInstance().getSongList();
        boolean allUsersRatedAllSongs = true;
        for(String userName : userList) {
            User user = UserRepository.getInstance().getUserByName(userName);
            for(String songName : songList) {
                Song song = SongRepository.getInstance().getSongByName(songName);
                if(!user.hasRated(song)) {
                    allUsersRatedAllSongs = false;
                    calculatePredictedRating(user, song);
                }
            }
            
            
        }
        if(allUsersRatedAllSongs && pathFlag.equals("-p")) {
                throw new IllegalStateException("Error: all users rated all songs, unable to do prediction");
            }

    }

    private static void calculatePredictedRating(User user1, Song song) {
        Map<Song, Double> predictedRatingsMap = user1.getPredictedRatingsMap();
        Map<User, Double> songPredictedRatingsMap = song.getPredictedRatingsMap();
        User user2 = getClosestUser(user1, song);
        if(user1.equals(user2)) {
            predictedRatingsMap.put(song, Double.NaN);
            return;
        }
        Double predictedRating = (double)Math.round(user2.getZScoreMap().get(song) * user1.getStandardDeviation() + user1.getAverageRating());
        if(predictedRating < 1) {
            predictedRating = 1.0;
        } else if(predictedRating > 5) {
            predictedRating = 5.0;
        }
        predictedRatingsMap.put(song, predictedRating);
        songPredictedRatingsMap.put(user1, predictedRating);


    }



    private static User getClosestUser(User user1, Song song) {

        Map<User, Double> similartyMap = user1.getSimilarityMap();
        User user2 = user1;
        Double closestSimilarity = Double.MAX_VALUE;
        for(User userX : similartyMap.keySet()) {
            if(userX.hasRated(song) && similartyMap.get(userX) < closestSimilarity) {
                user2 = userX;
                closestSimilarity = similartyMap.get(userX);
            }
        }
        return user2;
    }

    public static void fillInMissingRatings(){

        ArrayList<String> userList = ListsRepository.getInstance().getUserList();

        for(String name : userList) {
            User user = UserRepository.getInstance().getUserByName(name);
            checkForMissingRatings(user);
        }
        
    }

    private static void checkForMissingRatings(User user) {
        Map<Song, Double> predictedRatingsMap = user.getPredictedRatingsMap();
        for(Song song : predictedRatingsMap.keySet()) {
            if(predictedRatingsMap.get(song).equals(Double.NaN)){
                double numerator = song.getAveRating() * song.getRatingsMap().size() + user.getAverageRating() * user.getRatingsMap().size();
                double denominator = song.getRatingsMap().size() + user.getRatingsMap().size();
                double unpredicted = Math.round(numerator / denominator);
                predictedRatingsMap.put(song, unpredicted);
                song.getPredictedRatingsMap().put(user, unpredicted);
            }
        }
    }


}

    




