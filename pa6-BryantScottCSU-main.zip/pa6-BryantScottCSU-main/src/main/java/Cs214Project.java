//module load courses/cs214

import java.util.ArrayList;

public class Cs214Project {

    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        
        try {
        callPaths(args);
        } catch(Exception e){
            System.err.println(e.getMessage());
        }


    }

    private static void callPaths(String[] args) throws Exception{

        if(args.length == 2) {
            SongStatsPath.pathOne(args[0], args[1]);
        } else if (args[2].equals("-a")) {
            UserStatsPath.pathTwo(args[0], args[1], args[2]);
        } else if (args[2].equals("-u")) {
            SongSimilarityPath.pathThree(args[0], args[1], args[2]);
        } else if(args[2].equals("-p")) {
            RatingPredictionPath.pathFour(args[0], args[1], args[2]);
        } else if(args[2].equals("-r") || args[2].equals("-s")) {
            complexCalls(args);
        } else {
            
            throw new IllegalArgumentException("Error incorrect number of arguments");
        }
    }

    public static void complexCalls(String[] args) throws Exception{


        switch (args[2]) {
            case "-r":
                {
                    ArrayList<String> userSongs = new ArrayList<>();
                    for(int i = 3; i < args.length; i++) {
                        userSongs.add(args[i]);
                    }       String arg0 = args[0] + "," + args[1];
                    SongRecomendationPath.pathFive(arg0, args[2], userSongs);
                    break;
                }
            case "-s":
                {
                    ArrayList<String> userProvidedSongs = new ArrayList<>();
                    for(int i = 4; i < args.length; i++) {
                        userProvidedSongs.add(args[i]);
                    }       String arg0 = args[0] + "," + args[1] + "," + args[3];
                    AlbumPath.pathSix(arg0, args[2], userProvidedSongs);
                    break;
                }
            default:
                throw new IllegalArgumentException("Error incorrect number of arguments");
        }
    }

        
    }


