import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class RatingPredictionPath {

    public static void pathFour(String inputFile, String outputFile, String pathFlag) throws Exception {

        
        ArrayList<String> userNames = ListsRepository.getInstance().getUserList();
        ArrayList<String> songNames = ListsRepository.getInstance().getSongList();
        
        InputFileReader.readFile(inputFile);
        removeDelinquentUsers(userNames);
        removeDelinquentSongs(songNames);
        if(userNames.size() < 2) {
            throw new IllegalStateException("Error: at least two cooperative users are required for rating prediction");
        }
        RatingHandler.populateUserSimilarities();
        RatingPredictor.predictRatings(pathFlag);
        writeFile(outputFile, userNames, songNames);

    }

  

    private static void removeDelinquentUsers(ArrayList<String> userNames) {

        Iterator<String> delinquentDeleter = userNames.iterator();
        while(delinquentDeleter.hasNext()){
            String user = delinquentDeleter.next();
            if(UserRepository.getInstance().getUserByName(user).isDelinquent()) {
                delinquentDeleter.remove();
            }
        }
    }

    
    private static void removeDelinquentSongs(ArrayList<String> songNames) {

        Iterator<String> delinquentDeleter = songNames.iterator();
        while(delinquentDeleter.hasNext()){
            String song = delinquentDeleter.next();
            if(SongRepository.getInstance().getSongByName(song).isDelinquent()) {
                delinquentDeleter.remove();
            }
        }
    }


    private static void writeFile(String fileName, ArrayList<String> userNames, ArrayList<String> songNames) throws Exception{

        checkFile(fileName);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {

            writer.write("song,user,predicted rating\n");
            Collections.sort(songNames);
            Collections.sort(userNames);
            for(int i = 0; i < songNames.size(); i++) {
                Song song = SongRepository.getInstance().getSongByName(songNames.get(i));
                writeLinesForSong(writer, song);              
            }


        } catch(FileNotFoundException e) {
            throw new FileNotFoundException("Error: directory does not exist");
        }
        }

        private static void writeLinesForSong(BufferedWriter writer, Song song) throws Exception{
            ArrayList<String> userNames = ListsRepository.getInstance().getUserList();
            for(int j = 0; j < userNames.size(); j++) {
                    User user = UserRepository.getInstance().getUserByName(userNames.get(j));
                    if(!user.getZScoreMap().containsKey(song)) {
                        writer.write(song.getName() + "," + user.getName()+ "," + RatingHandler.formatDouble(user.getPredictedRatingsMap().get(song)) + "\n");
                    }
                } 

        }
        private static void checkFile(String fileName) throws Exception{
            
            if(!fileName.toLowerCase().endsWith(".csv")) {
            throw new IOException("Error: output file does not have .csv extention");
            }

        }
    
}
