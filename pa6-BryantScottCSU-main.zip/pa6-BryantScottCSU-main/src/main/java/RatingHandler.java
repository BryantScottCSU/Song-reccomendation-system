import java.util.ArrayList;
import java.util.Map;

public class RatingHandler {
    

    public static  void rateSong(String line) {

        String[] thisLine = line.split(","); // 0 == song name, 1 == user name, 2 == rating;
        Song thisSong;
        User thisUser;
        if(SongRepository.getInstance().hasSong(thisLine[0])){
            thisSong = SongRepository.getInstance().getSongByName(thisLine[0]);
        } else {
            SongRepository.getInstance().addSong(thisLine[0]);
            ListsRepository.getInstance().getSongList().add(thisLine[0]);
            thisSong = SongRepository.getInstance().getSongByName(thisLine[0]);
        }

        if(UserRepository.getInstance().hasUser(thisLine[1])) {
            thisUser = UserRepository.getInstance().getUserByName(thisLine[1]);
            thisUser.getRatingsMap().put(thisSong, Integer.valueOf(thisLine[2]));
            thisSong.getRatingsMap().put(thisUser, Integer.valueOf(thisLine[2]));
        } else {
            UserRepository.getInstance().addUser(thisLine[1]);
            ListsRepository.getInstance().getUserList().add(thisLine[1]);
            thisUser = UserRepository.getInstance().getUserByName(thisLine[1]);
            thisUser.getRatingsMap().put(thisSong, Integer.valueOf(thisLine[2]));
            thisSong.getRatingsMap().put(thisUser, Integer.valueOf(thisLine[2]));
        }
    }

    public static void calculateStats() {

        ArrayList<String> songList = ListsRepository.getInstance().getSongList();


        for(String songName : songList) {
            Song song = SongRepository.getInstance().getSongByName(songName);
            song.setAverageRating(calculateAverage(song));
            song.setStandardDiv(caclulateStandardDiv(song));
        }

        populateZScores();
    }

    private static double calculateAverage(Song song) {
        ArrayList<Integer> ratings = new ArrayList<>(song.getRatingsMap().values());
        int sum = 0;
        for(int rating : ratings) {
            sum+= rating;
        }
        double average = (double) sum / ratings.size();
        return average;

    }

        public static double calculateAverage(User user) {
        ArrayList<Integer> ratings = new ArrayList<>(user.getRatingsMap().values());
        int sum = 0;
        for(int rating : ratings) {
            sum+= rating;
        }
        double average = (double) sum / ratings.size();
        user.setAverageRating(average);
        return average;

    }


    private static double caclulateStandardDiv(Song song) {
        
        double average = song.getAveRating();
        ArrayList<Integer> ratings = new ArrayList<>(song.getRatingsMap().values());
        
        double squaredDifferenceSum = 0;
        for(int rating : ratings) {
            double difference = rating - average;
            squaredDifferenceSum += difference * difference;
        }
        double variance = squaredDifferenceSum / ratings.size();
        
        return Math.sqrt(variance);
    }

        public static double caclulateStandardDiv(User user) {
        
            Map<Song, Integer> ratingsMap = user.getRatingsMap();
            double sum = 0;
            for(Integer rating : ratingsMap.values()) {
                sum += rating;
            }
            double average = sum / ratingsMap.size();
            double standardDiv;
            double sumSquaredDif = 0;
            for(Integer rating : ratingsMap.values()) {
                double thisRating = rating;
                thisRating = thisRating - average;
                thisRating = Math.pow(thisRating, 2);
                sumSquaredDif += thisRating;
            }

            
            standardDiv = Math.sqrt(sumSquaredDif / ratingsMap.size());
            user.setStandardDeviation(standardDiv);
            return standardDiv;
    }

    private static void populateZScores() {
        ArrayList<String> userList = ListsRepository.getInstance().getUserList();

        for(String userName : userList) {

            User user = UserRepository.getInstance().getUserByName(userName);
            double standardDeviation = caclulateStandardDiv(user);

            for(Song song : user.getRatingsMap().keySet()) {
            double rating = user.getRatingsMap().get(song);
            rating = rating - calculateAverage(user);
            double zScore = rating/standardDeviation;
            user.getZScoreMap().put(song, zScore); 
            song.getZScoreMap().put(user, zScore);

        }
        }

    }



    public static String formatDouble(Double toBeFormatted) {
        //System.out.println("The number we're formmating is " + toBeFormatted);
        if(toBeFormatted.isNaN()) {
            return "NaN";
        }
        if(toBeFormatted < 1.0) {
            toBeFormatted = 1.0;
        } else if(toBeFormatted > 5.0) {
            toBeFormatted = 5.0;
        }
        Integer intFormat = toBeFormatted.intValue();
        return intFormat.toString();

    }

    public static void populateUserSimilarities() {

        ArrayList<String> userNames = ListsRepository.getInstance().getUserList();

        for(int i = 0; i < userNames.size(); i++) {
                for(int j = i + 1; j < userNames.size(); j++) {
                    User user1 = UserRepository.getInstance().getUserByName(userNames.get(i));
                    User user2 = UserRepository.getInstance().getUserByName(userNames.get(j));
                    EuclideanCalc.calculateDistance(user1, user2);
                }               
            }
        //printUserSimilarites();
    }
    


}
