import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class DataOrganizer {
    

    public static HashMap<String, Centroid> makeMap(ArrayList<String> userSongs, ArrayList<Centroid> centroidList) {
        
        HashMap<String, Centroid> toReturn = new HashMap<>();

        for(int i = 0; i < userSongs.size(); i++) {
            toReturn.put(userSongs.get(i), centroidList.get(i));
        }
        return toReturn;
    }

    public static ArrayList<String> sortSongList(ArrayList<Song> songList) {
        ArrayList<String> toReturn = new ArrayList<>();

        for(Song song : songList) {
            toReturn.add(song.getName());
        }
        Collections.sort(toReturn);
        return toReturn;
    }
}
