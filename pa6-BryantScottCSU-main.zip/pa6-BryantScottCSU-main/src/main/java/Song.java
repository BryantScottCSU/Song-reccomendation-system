
import java.util.HashMap;
import java.util.Map;

public class Song {
 
    private final String name;
    private boolean delinquent;
    private double averageRating;
    private double standardDeviation;
    private final Map<User, Integer> ratingsMap;
    private final Map<User,Double> zScoresMap;
    private final Map<User, Double> predictedRatingsMap;
    private final Map<User, Double> predictedRatingsNormalMap;
    private double perdictedAverage;
    private double predictedStdDiv;
    private double bestDistance;


    public Song(String name){

        this.name = name;
        delinquent = true;
        ratingsMap = new HashMap<>();
        zScoresMap = new HashMap<>();
        predictedRatingsMap = new HashMap<>();
        predictedRatingsNormalMap = new HashMap<>();
        perdictedAverage = 0;
        predictedStdDiv = 0;
        bestDistance = 0;

    }

    public String getName() {
        return name;
    }

    public double getAveRating() {
        return averageRating;
    }

    public double getPredictedAverage() {
        return perdictedAverage;
    }
    
    public double getStandardDiv() {
        return standardDeviation;
    }

    public double getPredictedStdDiv(){
        return predictedStdDiv;
    }

    public Map<User, Integer> getRatingsMap() {
        return ratingsMap;
    }

    public boolean isDelinquent(){
        for(User user : ratingsMap.keySet()) {
            if(!user.isDelinquent()) {
                delinquent = false;
            }
        }

        return delinquent;
    }

    public Map<User, Double> getZScoreMap() {
        return zScoresMap;
    }

    public Map<User, Double> getPredictedRatingsMap() {
        return predictedRatingsMap;
    }

    public Map<User, Double> getPredictedRatingsNormalMap() {
        return predictedRatingsNormalMap;
    }

    public boolean ratedBy(User user){
        return ratingsMap.containsKey(user);
    }

    public void setAverageRating(double num) {
        averageRating = num;
    }

    public void setStandardDiv(double num) {
        this.standardDeviation = num;
    }

    public void setPredictedAverageRating(double num) {
       perdictedAverage = num;
    }

    public void setPredictedStandardDiv(double num) {
        predictedStdDiv = num;
    }

    public double getBestDistnace() {
        return bestDistance;
    }

    public void setBestDistance(double bestDistance) {
        this.bestDistance = bestDistance;
    }

}
