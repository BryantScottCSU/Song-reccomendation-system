import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class SongStatsPath {
    
//ADD A LIST TO THE SONG OBJECT THAT TRACKS EVERY USER THAT HAS RATED IT, CHANGE THE RATE METHOD FOR THE SONGS TO TAKE IN TO ARGS, USER AND RATING. USE THAT LIST TO CHECK IF ALL
//USERS WHO HAVE RATED THE SONG ARE DELINQUENT
    public static void pathOne(String inputFile, String outputFile) throws Exception {

        ArrayList<String> songNames = ListsRepository.getInstance().getSongList();


        InputFileReader.readFile(inputFile);
        writeFile(outputFile, songNames);

        //System.out.println("Total songs = " + SongRepository.getInstance().totalSongs());
    }


    private static void writeFile(String fileName, ArrayList<String> songNames) throws Exception{
        

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {

            checkFile(fileName);
            writer.write("song,number of ratings,mean,standard deviation\n");
            Collections.sort(songNames);
            //System.out.println(songNames);
            writeLines(writer);

        } catch(FileNotFoundException e) {
            throw new FileNotFoundException("Error: directory does not exist");
        } catch (IOException e) {
            throw new IOException("Error: file lacks .csv extention");
        }
        }

        private static void writeLines(BufferedWriter writer) throws Exception{
            
            ArrayList<String> songNames = ListsRepository.getInstance().getSongList();
            for(Object songName : songNames) {
                Song song = SongRepository.getInstance().getSongByName(songName.toString());
                writer.write(song.getName() + ",");
                writer.write(song.getRatingsMap().size() + ",");
                writer.write(song.getAveRating() + ",");
                writer.write(song.getStandardDiv() + "\n");
            }

        }

        private static void checkFile(String fileName) throws Exception{
            if(!fileName.toLowerCase().endsWith(".csv")) {
            throw new IOException("Error: file lacks .csv extention");
            }
        }

}
