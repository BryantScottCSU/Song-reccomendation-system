import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class AlbumPath {
    

    public static void pathSix(String arg0, String pathFlag, ArrayList<String> userProvidedSongs) throws Exception {

        String[] argsArray = arg0.split(",");
        String inputFile = argsArray[0];
        String outputFile = argsArray[1];
        int k = Integer.parseInt(argsArray[2]);
        ArrayList<String> userSongs = new ArrayList<>();
        if(k > userProvidedSongs.size()) {
            throw new IllegalStateException("Error: k is larger than number of user provided songs");
        }
        for(int i = 0; i < k; i++) {
                userSongs.add(userProvidedSongs.get(i));
            }
        if(userSongs.isEmpty()) {
            throw new IllegalStateException("Error: no songs provided after -s flag");
        }

        ArrayList<String> userNames = ListsRepository.getInstance().getUserList();
        ArrayList<String> songNames = ListsRepository.getInstance().getSongList();

        InputFileReader.readFile(inputFile);
        removeDelinquentUsers(userNames);
        removeDelinquentSongs(songNames);
        
        if(userNames.size() < 2) {
            throw new IllegalStateException("Error: at least two cooperative users are required for song reccomendation");
        }
        RatingHandler.populateUserSimilarities();
        RatingPredictor.predictRatings(pathFlag);
        RatingPredictor.fillInMissingRatings();
        PredictedRatingHandler.mergeMaps();
        PredictedRatingHandler.normalizePredictedRatings();
        DataChecker.checkData(userSongs);
        ArrayList<Centroid> centroidList = KMeans.runKMeansClustering(userSongs);
        HashMap<String, Centroid> userSongToCentroidMap = DataOrganizer.makeMap(userSongs, centroidList);
        DataChecker.checkClusters(userSongToCentroidMap, userSongs);
        ArrayList<String> album = AlbumBuilder.makeAlbum(userProvidedSongs, centroidList);
        writeFile(outputFile, userSongs, album);

    }


        private static void removeDelinquentUsers(ArrayList<String> userNames) {

        Iterator<String> delinquentDeleter = userNames.iterator();
        while(delinquentDeleter.hasNext()){
            String user = delinquentDeleter.next();
            if(UserRepository.getInstance().getUserByName(user).isDelinquent()) {
                delinquentDeleter.remove();
            }
        }
    }

    
    private static void removeDelinquentSongs(ArrayList<String> songNames) {

        Iterator<String> delinquentDeleter = songNames.iterator();
        while(delinquentDeleter.hasNext()){
            String song = delinquentDeleter.next();
            if(SongRepository.getInstance().getSongByName(song).isDelinquent()) {
                delinquentDeleter.remove();
            }
        }
    }

    private static void writeFile(String fileName, ArrayList<String> userProvidedSongs, ArrayList<String> album) throws Exception{

        checkFile(fileName);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {

            int i = 0;
            for(String songName : album) {
                if(i >= 20) {
                    break;
                }
                if(!isUserSong(songName, userProvidedSongs)){
                    writer.write(songName);
                    i++;
                    if(i != album.size()) {
                        writer.write("\n");
                    }
                }
            } 


        } catch(FileNotFoundException e) {
            throw new FileNotFoundException("Error: directory does not exist");
        }
        }

    private static boolean isUserSong(String songName, ArrayList<String> userSongs) {

        
        for(String userSong : userSongs) {
            if(userSong.equals(songName)) {
                return true;
            }
        }

        return false;
    }


    private static void checkFile(String fileName) throws Exception{
            
        if(!fileName.toLowerCase().endsWith(".csv")) {
        throw new IOException("Error: output file does not have .csv extention");
        }

     }
    }
