import java.util.HashMap;
import java.util.Map;

public final class UserRepository {
    private final Map<String, User> userMap;
    private static UserRepository instance = null;

    public void clearForTests() {
        instance = null;
        getInstance();
    }

    private UserRepository() {
        userMap = new HashMap<>();
    }

    public static UserRepository getInstance() {
        if (instance == null){
            instance = new UserRepository();
        }
        return instance;
    }

    public void addUser(String toAdd) {
        User user = new User(toAdd);
        userMap.put(toAdd, user);
    }


    public User getUserByName(String userName) {

        if(hasUser(userName)){
            return userMap.get(userName);
        } else {
            return null;
        }

        
    }

    public boolean hasUser(String name) {

        return userMap.containsKey(name);
            
    }

    public int totalUsers() {
        return userMap.size();
    }

    
}
