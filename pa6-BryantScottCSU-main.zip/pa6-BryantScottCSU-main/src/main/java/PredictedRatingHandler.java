import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public class PredictedRatingHandler {
    
    public static void mergeMaps() {
        ArrayList<String> userNames = ListsRepository.getInstance().getUserList();
        for(String userName : userNames) {
            User user = UserRepository.getInstance().getUserByName(userName);
            checkMapForSong(user);
        }

        ArrayList<String> songNames = ListsRepository.getInstance().getSongList();
        for(String songName : songNames) {
            Song song = SongRepository.getInstance().getSongByName(songName);
            checkMapForUser(song);
        }
        removeSongsOneRating();
    }

    private static void checkMapForSong(User user) {
        ArrayList<String> songNames = ListsRepository.getInstance().getSongList();
        Map<Song, Double> predictedMap = user.getPredictedRatingsMap();
        for(String songName : songNames) {
            Song song = SongRepository.getInstance().getSongByName(songName);
            if(!predictedMap.containsKey(song)) {
                predictedMap.put(song, (double)user.getRatingsMap().get(song));
            }
        }
    }

    private static void checkMapForUser(Song song){
        ArrayList<String> userNames = ListsRepository.getInstance().getUserList();
        Map<User, Double> predictedMap = song.getPredictedRatingsMap();
        for(String userName : userNames) {
            User user = UserRepository.getInstance().getUserByName(userName);
            if(!predictedMap.containsKey(user)){
                predictedMap.put(user, (double)song.getRatingsMap().get(user));
            }
        }
    }

    public static void normalizePredictedRatings() {
        ArrayList<String> userNames = ListsRepository.getInstance().getUserList();
        setSongsPredictedStats();
        for(String userName : userNames) {
            User user = UserRepository.getInstance().getUserByName(userName);
            calculateNormalizedRatings(user);
        }

    }



    private static void calculateNormalizedRatings(User user) {
        Map<Song, Double> predictedMap = user.getPredictedRatingsMap();
        Map<Song, Double> predictedNormalMap = user.getPredictedRatingsNormalMap();
        for(Song song : predictedMap.keySet()) {
            Map<User, Double> songPredictedNormalMap = song.getPredictedRatingsNormalMap();
            double normalizedRating = (predictedMap.get(song) - song.getPredictedAverage()) / song.getPredictedStdDiv();

            predictedNormalMap.put(song, normalizedRating);
            songPredictedNormalMap.put(user, normalizedRating);
        }
    }


    private static void setSongsPredictedStats() {
        ArrayList<String> songNames = ListsRepository.getInstance().getSongList();

        for(String songName : songNames) {
            Song song = SongRepository.getInstance().getSongByName(songName);
            caclulateSongAverage(song);
            calculateSongStdDiv(song);
        }
    }

    private static void caclulateSongAverage(Song song) {
        ArrayList<String> userNames = ListsRepository.getInstance().getUserList();
        double sum = 0;

        for(String userName : userNames) {
            User user = UserRepository.getInstance().getUserByName(userName);
            sum += song.getPredictedRatingsMap().get(user);
        }
        double average = sum / (song.getPredictedRatingsMap().size());
        song.setPredictedAverageRating(average);
    }

    private static void calculateSongStdDiv(Song song) {
        
        double average = song.getPredictedAverage();
        ArrayList<Double> ratings = new ArrayList<>(song.getPredictedRatingsMap().values());
        
        double squaredDifferenceSum = 0;
        for(Double rating : ratings) {
            double difference = rating - average;
            squaredDifferenceSum += difference * difference;
        }
        double variance = squaredDifferenceSum / ratings.size();
        
        song.setPredictedStandardDiv(Math.sqrt(variance));
    }

    private static void removeSongsOneRating() {
        ArrayList<String> songNames = ListsRepository.getInstance().getSongList();
        Iterator<String> delinquentDeleter = songNames.iterator();
        while(delinquentDeleter.hasNext()) {
            Song song = SongRepository.getInstance().getSongByName(delinquentDeleter.next());
            Map<User, Double> ratingsMap = song.getPredictedRatingsMap();
            boolean hasVariance = hasVariance(ratingsMap);
            if(!hasVariance) {
                delinquentDeleter.remove();
            }
        }
    }

    private static boolean hasVariance(Map<User, Double> ratingsMap) {

        Double thisRating = null;
        for (double r : ratingsMap.values()) {
            if (thisRating == null){
                thisRating = r;
            } 
            else if (!thisRating.equals(r)) return true;
        }
        return false;
    }
}
