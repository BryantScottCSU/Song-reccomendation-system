import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;


/**
 * @version DataChecker checks that our userSongs data is in the correct state for processing
 */
public class DataChecker {
    
/**
 * 
 * @param userSongs list of songs provided by user in terminal
 * @throws Exception throws exceptions if error condition is found
 */
    public static void checkData(ArrayList<String> userSongs) throws Exception {
        int k = userSongs.size();
        ArrayList<String> songNames = ListsRepository.getInstance().getSongList();
        if(!(songNames.size() > k+1)) {
            throw new IllegalStateException("Error: data does not contain k+1 songs after removing songs without distinct predicted ratings");
        }

        checkForInvalidUserSong(userSongs, songNames);
        checkForDuplicates(userSongs);
    }
/**
 * 
 * @param userSongs list of songs provided by user in terminal
 * @param songNames global list of all songs in database
 * @throws Exception if userSong is not in songNames
 */
    private static void checkForInvalidUserSong(ArrayList<String> userSongs, ArrayList<String> songNames) throws Exception{

        for(String userSong : userSongs) {
            boolean found = false;
            for(String songName : songNames) {
                if(userSong.equals(songName)) {
                    found = true;
                }
            }
            if(!found) {
                throw new IllegalStateException("Error: selected song does not match a song in dataset");
            }
        }
    }

    /**
     * 
     * @param userSongs
     * @throws Exception
     */
    private static void checkForDuplicates(ArrayList<String> userSongs) throws Exception {

        boolean hasDuplicates = false;
        Set<String> userSongsSet = new HashSet<>();
        for(String userSong : userSongs) {
            if(!userSongsSet.add(userSong)) {
                 hasDuplicates = true;
            }
        }
        
        if(hasDuplicates) {
            throw new IllegalArgumentException("Error: Duplicate user song arguments");
        }

        
    }
/**
 * 
 * @param userSongToCentroidMap
 * @param userSongs
 * @throws Exception
 */    public static void checkClusters(HashMap<String, Centroid> userSongToCentroidMap, ArrayList<String> userSongs) throws Exception {
        checkAllClustersEmpty(userSongToCentroidMap, userSongs);
    }
/**
 * 
 * @param userSongToCentroidMap
 * @param userSongs
 * @throws Exception
 */
    private static void checkAllClustersEmpty(HashMap<String, Centroid> userSongToCentroidMap, ArrayList<String> userSongs) throws Exception {
        boolean allEmpty = true;
        boolean onlyHasUserSongs = true;
        for(String userSong : userSongs) {
            if(!userSongToCentroidMap.get(userSong).getCluster().isEmpty()) {
                allEmpty = false;
            }
            if(!justHasUserSongs(userSongToCentroidMap, userSongs)) {
                onlyHasUserSongs = false;
            }
        }
        if(allEmpty || onlyHasUserSongs) {
            throw new IllegalStateException("Error: All clusters are empty or just have user songs");
        }
    }
/**
 * 
 * @param userSongToCentroidMap
 * @param userSongs
 * @return
 */
    private static boolean justHasUserSongs(HashMap<String, Centroid> userSongToCentroidMap, ArrayList<String> userSongs) {
        boolean onlyHasUserSongs = true;
        for(Centroid centroid : userSongToCentroidMap.values()) {
            ArrayList<Song> cluster = centroid.getCluster();
            for(Song song : cluster) {
                if(!userSongs.contains(song.getName())) {
                    onlyHasUserSongs = false;
                    return onlyHasUserSongs;
                }
            }
        }
        return onlyHasUserSongs;
    }


}
