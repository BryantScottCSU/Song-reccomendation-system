import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.InputMismatchException;

public class InputFileReader {
    


/**
 * 
 * @param fileName
 * @throws Exception
 */
    public static void readFile(String fileName) throws Exception{

        checkFile(fileName);
        String line;
        try (BufferedReader fileReader = new BufferedReader(new FileReader(fileName))){

            while((line = fileReader.readLine()) != null) {

                line = line.trim();

                String[] thisLine = line.split(","); 
                checkLine(thisLine);

                RatingHandler.rateSong(line);
            }
            fileReader.close();
            RatingHandler.calculateStats();
            
         } catch(IOException e) {
            throw new IOException("Error: IOException when attempting to read file, unexpected error");
         } 
    }
/**
 * 
 * @param thisLine
 * @throws Exception
 */
    private static void checkLine(String[] thisLine) throws Exception {
        
                if(thisLine.length !=  3) {
                    
                }
                if(validRating(thisLine)) {
                    throw new InputMismatchException("Error: rating is not 1-5, or is not an integer");
                }
    }
/**
 * 
 * @param thisLine
 * @return
 */
    private static boolean validRating(String[] thisLine) {
        return !thisLine[2].equals("1") && !thisLine[2].equals("2") && !thisLine[2].equals("3") && !thisLine[2].equals("4") && !thisLine[2].equals("5");
    }
/**
 * 
 * @param fileName
 * @throws Exception
 */
    private static void checkFile(String fileName)throws Exception {
        
        try (BufferedReader fileReader = new BufferedReader(new FileReader(fileName))){
            
            isCSV(fileName);
            
            isEmpty(fileReader);

            
            fileReader.close();
         } catch (FileNotFoundException e) {
            throw new FileNotFoundException("Error: input file does not exist");
         } 
    }
/**
 * 
 * @param fileName
 * @throws IOException
 */
    private static void isCSV(String fileName) throws IOException {
 
            if(!fileName.toLowerCase().endsWith(".csv")) {

                throw new IOException("Error: input file does not have .CSV extention");
            }        

    }
/**
 * 
 * @param fileReader
 * @throws IOException
 */
    private static void isEmpty(BufferedReader fileReader) throws IOException {
 
            if(fileReader.readLine() == null) {
                throw new IllegalStateException("Error: input file is empty");
            }
    }


}
