import java.util.ArrayList;
import java.util.Collections;

public final class ListsRepository {
    
    private ArrayList<String> userList = null;
    private ArrayList<String> songList = null;
    private static ListsRepository instance = null;

     private ListsRepository() {
        userList = new ArrayList<>();
        songList = new ArrayList<>();
    }

    public void clearForTests() {
        instance = null;
        getInstance();
    }
    
    public static ListsRepository getInstance() {
        if (instance == null){
            instance = new ListsRepository();
        }
        return instance;
    }

    public ArrayList<String> getUserList() {
        Collections.sort(userList);
        return userList;
    }

    public ArrayList<String> getSongList() {
        Collections.sort(songList);
        return songList;
    }

}
