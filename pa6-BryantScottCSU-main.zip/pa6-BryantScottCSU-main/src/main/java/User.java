import java.util.HashMap;
import java.util.Map;

public class User {
    
    private final String name;
    private boolean delinquent;
    private final Map<Song, Integer> songRatingsMap;
    private final Map<Song, Double> ratingZScores;
    private final Map<User, Double> similarityMap;
    private double averageRating;
    private double standardDeviation;
    private final Map<Song, Double> predictedRatingsMap;
    private final Map<Song, Double> predictedRatingsNormalMap;

    public User(String name) {
        this.name = name;
        this.delinquent = true;
        songRatingsMap = new HashMap<>();
        ratingZScores = new HashMap<>();
        similarityMap = new HashMap<>();
        predictedRatingsMap = new HashMap<>();
        predictedRatingsNormalMap = new HashMap<>();
        

    }

    public String getName() {
        return name;
    }

    public boolean isDelinquent() {
       delinquent = !hasVariance();
       return delinquent;
    }
    
    public Map<Song, Integer> getRatingsMap() {
        return songRatingsMap;
    }


    public int ratedSongsSize(){
        return songRatingsMap.size();
    }

    public Map<Song, Double> getZScoreMap() {
        return ratingZScores;
    }

    public Map<Song, Double> getPredictedRatingsMap() {
        return predictedRatingsMap;
    }

    public Map<Song, Double> getPredictedRatingsNormalMap() {
        return predictedRatingsNormalMap;
    }

    public double getAverageRating() {
        return averageRating;
    }

    public double getStandardDeviation() {
        return standardDeviation;
    }

    public Map<User, Double> getSimilarityMap() {
        return similarityMap;
    }
    public boolean hasRated(Song song){
        return songRatingsMap.containsKey(song);
    }

    private boolean hasVariance() {
        Integer thisRating = null;
        for (int r : songRatingsMap.values()) {
            if (thisRating == null){
                thisRating = r;
            } 
            else if (!thisRating.equals(r)) return true;
        }
        return false;
    }    

    public void setAverageRating(double averageRating) {
        this.averageRating = averageRating;
    }

    public void setStandardDeviation(double standardDeviation) {
        this.standardDeviation = standardDeviation;
    }

}
