import java.util.ArrayList;
import java.util.LinkedHashSet;

public class AlbumBuilder {
    public static ArrayList<String> makeAlbum(ArrayList<String> userProvidedSongs, ArrayList<Centroid> centroidList) {
        ArrayList<String> album = new ArrayList<>();

        for(String providedSong : userProvidedSongs) {
            Song s = SongRepository.getInstance().getSongByName(providedSong);
            Centroid c = getSongCluster(s, centroidList);
            for(Song t : c.getCluster()) {
                setDistance(s, t, album);
            }

        }
        album = sortAlbum(album);
        album = new ArrayList<>(new LinkedHashSet<>(album));
        return album;
    }

    private static Centroid getSongCluster(Song s, ArrayList<Centroid> centroidList) {
        Centroid centroid = new Centroid(s);
        for(Centroid c : centroidList) {
            if(c.clusterHasSong(s)){
                centroid = c;
                break;
            }
        }
        return centroid;
    }

    private static void setDistance(Song s, Song t, ArrayList<String> album) {
        if(s.equals(t)) {
            return;
        }
        double[] sVector = EuclideanCalc.getArray(s);
        double[] tVector = EuclideanCalc.getArray(t);
        double d = 1 / EuclideanCalc.calculateDistance(tVector, sVector);
        double sBest = s.getBestDistnace();
        double tBest = t.getBestDistnace();
        if(d > sBest) {
            s.setBestDistance(d);
        }
        if(d > tBest) {
            t.setBestDistance(d);
        }
        album.add(t.getName());
    }

    private static ArrayList<String> sortAlbum(ArrayList<String> album) {
        
        boolean swapped;
        for(int i = 0; i < album.size() - 1; i++) {
            swapped = false;
            for(int j = 0; j < album.size() - 1 - i; j++) {
                Song s = SongRepository.getInstance().getSongByName(album.get(j));
                Song t = SongRepository.getInstance().getSongByName(album.get(j+1));
                if(s.getBestDistnace() < t.getBestDistnace()) {
                    Song temp = s;
                    album.set(j, t.getName());
                    album.set(j+1, temp.getName());
                    swapped = true;
                }
            }
            if(!swapped) {
            break;
            }
        }

        return album;
        

    }



}
