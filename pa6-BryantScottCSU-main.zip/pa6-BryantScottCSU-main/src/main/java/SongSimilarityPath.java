import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class SongSimilarityPath {
    

    public static void pathThree(String inputFile, String outputFile, String pathFlag) throws Exception {

        ArrayList<String> userNames = ListsRepository.getInstance().getUserList();
        ArrayList<String> songNames = ListsRepository.getInstance().getSongList();
        
        InputFileReader.readFile(inputFile);
        removeDelinquentUsers(userNames);
        removeDelinquentSongs(songNames);
        if(userNames.size() < 2) {
            throw new IllegalStateException("Error: at least two cooperative users are required for song similarity");
        }
        writeFile(outputFile, songNames);

    }

  

    private static void removeDelinquentUsers(ArrayList<String> userNames) {

        Iterator<String> delinquentDeleter = userNames.iterator();
        while(delinquentDeleter.hasNext()){
            String user = delinquentDeleter.next();
            if(UserRepository.getInstance().getUserByName(user).isDelinquent()) {
                delinquentDeleter.remove();
            }
        }
    }

    
    private static void removeDelinquentSongs(ArrayList<String> songNames) {

        Iterator<String> delinquentDeleter = songNames.iterator();
        while(delinquentDeleter.hasNext()){
            String song = delinquentDeleter.next();
            if(SongRepository.getInstance().getSongByName(song).isDelinquent()) {
                delinquentDeleter.remove();
            }
        }
    }


    private static void writeFile(String fileName, ArrayList<String> songNames) throws Exception{

        

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {

            checkFile(fileName);
            writer.write("name1,name2,similarity\n");
            Collections.sort(songNames);
            for(int i = 0; i < songNames.size(); i++) {
                writeLinesForSong(writer, i);              
            }


        } catch(FileNotFoundException e) {
            throw new FileNotFoundException("Error: directory does not exist");
        } 
        }

    
        private static void writeLinesForSong(BufferedWriter writer, int i) throws Exception{
            ArrayList<String> songNames = ListsRepository.getInstance().getSongList();
                for(int j = i + 1; j < songNames.size(); j++) {
                    Song song1 = SongRepository.getInstance().getSongByName(songNames.get(i));
                    Song song2 = SongRepository.getInstance().getSongByName(songNames.get(j));
                    writer.write(songNames.get(i) + "," + songNames.get(j)+ "," + EuclideanCalc.calculateDistance(song1, song2) + "\n");
                }  

        }
        private static void checkFile(String fileName) throws Exception{
            
            if(!fileName.toLowerCase().endsWith(".csv")) {
            throw new IOException("Error: output file does not have .csv extention");
            }

        }        


}


