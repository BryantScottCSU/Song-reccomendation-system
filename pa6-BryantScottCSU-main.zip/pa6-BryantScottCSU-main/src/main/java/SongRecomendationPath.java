import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;

public class SongRecomendationPath {
    
/**
 * 
 * @param arg0 a combination of args 0, and args 1
 * @param pathFlag
 * @param userSongs
 * @throws Exception
 */
    public static void pathFive(String arg0, String pathFlag, ArrayList<String> userSongs) throws Exception {

        String[] argsArray = arg0.split(",");
        String inputFile = argsArray[0];
        String outputFile = argsArray[1];
        if(userSongs.isEmpty()) {
            throw new IllegalStateException("Error: no songs provided after -r flag");
        }

        ArrayList<String> userNames = ListsRepository.getInstance().getUserList();
        ArrayList<String> songNames = ListsRepository.getInstance().getSongList();

        InputFileReader.readFile(inputFile);
        removeDelinquentUsers(userNames);
        removeDelinquentSongs(songNames);
        
        if(userNames.size() < 2) {
            throw new IllegalStateException("Error: at least two cooperative users are required for song reccomendation");
        }
        RatingHandler.populateUserSimilarities();
        RatingPredictor.predictRatings(pathFlag);
        RatingPredictor.fillInMissingRatings();
        PredictedRatingHandler.mergeMaps();
        PredictedRatingHandler.normalizePredictedRatings();
        DataChecker.checkData(userSongs);
        ArrayList<Centroid> centroidList = KMeans.runKMeansClustering(userSongs);
        HashMap<String, Centroid> userSongToCentroidMap = DataOrganizer.makeMap(userSongs, centroidList);
        DataChecker.checkClusters(userSongToCentroidMap, userSongs);
        writeFile(outputFile, userSongs, userSongToCentroidMap);

    }


        private static void removeDelinquentUsers(ArrayList<String> userNames) {

        Iterator<String> delinquentDeleter = userNames.iterator();
        while(delinquentDeleter.hasNext()){
            String user = delinquentDeleter.next();
            if(UserRepository.getInstance().getUserByName(user).isDelinquent()) {
                delinquentDeleter.remove();
            }
        }
    }

    
    private static void removeDelinquentSongs(ArrayList<String> songNames) {

        Iterator<String> delinquentDeleter = songNames.iterator();
        while(delinquentDeleter.hasNext()){
            String song = delinquentDeleter.next();
            if(SongRepository.getInstance().getSongByName(song).isDelinquent()) {
                delinquentDeleter.remove();
            }
        }
    }

    private static void writeFile(String fileName, ArrayList<String> userSongs, HashMap<String, Centroid> userSongToCentroidMap) throws Exception{

        checkFile(fileName);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {

            writer.write("user choice,recommendation\n");
            Collections.sort(userSongs);
            for(int i = 0; i < userSongs.size(); i++) {
                Song userSong = SongRepository.getInstance().getSongByName(userSongs.get(i));
                Centroid centroid = userSongToCentroidMap.get(userSongs.get(i));
                ArrayList<Song> reccomendedSongs = centroid.getCluster();
                ArrayList<String> reccomendedSongNames = DataOrganizer.sortSongList(reccomendedSongs);
                for(String songName : reccomendedSongNames) {
                    if(!userSong.getName().equals(songName) && !isUserSong(songName, userSongs)){
                    writer.write(userSong.getName() + "," + songName + "\n");
                    }
                }              
            }


        } catch(FileNotFoundException e) {
            throw new FileNotFoundException("Error: directory does not exist");
        }
        }

    private static boolean isUserSong(String songName, ArrayList<String> userSongs) {

        
        for(String userSong : userSongs) {
            if(userSong.equals(songName)) {
                return true;
            }
        }

        return false;
    }


    private static void checkFile(String fileName) throws Exception{
            
        if(!fileName.toLowerCase().endsWith(".csv")) {
        throw new IOException("Error: output file does not have .csv extention");
        }

     }
}
