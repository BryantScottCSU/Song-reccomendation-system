import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class UserStatsPath {
    


    public static void pathTwo(String inputFile, String outputFile, String pathFlag) throws Exception {

        
        if(!pathFlag.equals("-a")) {
            Exception newError = new IllegalArgumentException("Error flag argument is incorrect value");
            throw newError;
        }

        ArrayList<String> userNames = ListsRepository.getInstance().getUserList();
        ArrayList<String> songNames = ListsRepository.getInstance().getSongList();
        
        InputFileReader.readFile(inputFile);
        removeDelinquentUsers(userNames);
        removeDelinquentSongs(songNames);
        writeFile(outputFile);
        
    }

        private static void removeDelinquentSongs(ArrayList<String> songNames) {

        Iterator<String> delinquentDeleter = songNames.iterator();
        while(delinquentDeleter.hasNext()){
            String song = delinquentDeleter.next();
            if(SongRepository.getInstance().getSongByName(song).isDelinquent()) {
                delinquentDeleter.remove();
            }
        }
    }

        private static void removeDelinquentUsers(ArrayList<String> userNames) {

        Iterator<String> delinquentDeleter = userNames.iterator();
        while(delinquentDeleter.hasNext()){
            String user = delinquentDeleter.next();
            if(UserRepository.getInstance().getUserByName(user).isDelinquent()) {
                delinquentDeleter.remove();
            }
        }
    }



    private static void writeFile(String fileName) throws Exception{

        ArrayList<String> userNames = ListsRepository.getInstance().getUserList();
        ArrayList<String> songNames = ListsRepository.getInstance().getSongList();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            checkFile(fileName);

            writer.write("username,song,rating\n");
            Collections.sort(userNames);
            Collections.sort(songNames);

            for(String userName : userNames) {
                User user = UserRepository.getInstance().getUserByName(userName);
                writeLinesForUser(writer, user);
            }

        } catch(FileNotFoundException e) {
            throw new FileNotFoundException("Error: directory does not exist");
        }
        }

        private static void writeLinesForUser(BufferedWriter writer, User user) throws Exception{

                ArrayList<Song> usersSongs = new ArrayList<>(user.getRatingsMap().keySet());
                ArrayList<String> songNames = ListsRepository.getInstance().getSongList();
                for(String songName : songNames) {
                    Song song = SongRepository.getInstance().getSongByName(songName);
                    if(usersSongs.contains(song)) {
                        writer.write(user.getName() + ",");
                        writer.write(song.getName() + ",");
                        writer.write(user.getRatingsMap().get(song) + "\n");
                    } else {
                        writer.write(user.getName() + ",");
                        writer.write(song.getName() + ",");
                        writer.write(Double.NaN + "\n");
                    }
                
                }            
        }

        private static void checkFile(String fileName) throws Exception{
            
            if(!fileName.toLowerCase().endsWith(".csv")) {
            throw new IOException("Error: output file does not have .csv extention");
            }

        }  

       

}
