import java.util.ArrayList;

public class KMeans {
    
    private static ArrayList<Centroid> centroidList;
/**
 * 
 * @param userSongs
 * @return
 */
    public static ArrayList<Centroid> runKMeansClustering(ArrayList<String> userSongs) {

        centroidList = new ArrayList<>();
        for(String songName : userSongs) {
            Song song = SongRepository.getInstance().getSongByName(songName);
            Centroid centroid = new Centroid(song);
            centroidList.add(centroid);   
        }

        for(int i = 0; i < 10; i++) {
            runIteration();
        }

        return centroidList;

    }

    private static void runIteration() {
        
        for(Centroid centroid : centroidList) {
            centroid.clearCluster();
        }

        assignSongsToClusters();
        recalculateVectors();
    }

    private static void assignSongsToClusters() {
        ArrayList<String> songNames = ListsRepository.getInstance().getSongList();
        for(String songName : songNames) {
            Song song = SongRepository.getInstance().getSongByName(songName);
            assignSong(song);

        }
    }
/**
 * 
 * @param song
 */
    private static void assignSong(Song song) {
        double minDistance = Double.MAX_VALUE;
        Centroid closest = centroidList.get(0);
        double[] songVector = EuclideanCalc.getArray(song);
        for(Centroid centroid : centroidList) {
            double distance = EuclideanCalc.calculateDistance(songVector, centroid.getVector());
            if(distance < minDistance) {
                minDistance = distance;
                closest = centroid;
            }
        }
        closest.addToCluster(song);
    }

    private static void recalculateVectors() {

        for(Centroid centroid : centroidList) {
            recalculateVector(centroid);
        }

    }
/**
 * 
 * @param centroid
 */
    private static void recalculateVector(Centroid centroid) {

        if(centroid.getCluster().isEmpty()) {
            return;
        }
        double[] centroidVector = centroid.getVector();
        int n = centroid.getCluster().size();
        ArrayList<Song> currentCluster = centroid.getCluster();
        for(int i = 0; i < centroidVector.length; i++) {
            double sum = 0;
            for(Song song : currentCluster) {
                sum += EuclideanCalc.getArray(song)[i];
            }
            double average = sum / n;
            centroidVector[i] = average;
        }

        centroid.setVector(centroidVector);
    }
}
