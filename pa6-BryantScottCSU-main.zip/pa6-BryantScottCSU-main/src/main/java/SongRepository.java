// TODO change static methods to non staic where applicable
import java.util.HashMap;
import java.util.Map;

public final class SongRepository {
    
    @SuppressWarnings("FieldMayBeFinal")
    private Map<String, Song> songMap;
    private static SongRepository instance = null;

    private SongRepository() {
        songMap = new HashMap<>();
    }

    public void clearForTests() {
        instance = null;
        getInstance();
    }
    
    public static SongRepository getInstance() {
        if (instance == null){
            instance = new SongRepository();
        }
        return instance;
    }

    public void addSong(String toAdd) {
        Song song = new Song(toAdd);
        songMap.put(toAdd, song);
    }

    public Song getSongByName(String songName) {

        if(hasSong(songName)){
            return songMap.get(songName);
        } else {
            return null;
        }

        
    }

    public boolean hasSong(String name) {

        return songMap.containsKey(name);
            
    }

    public int totalSongs() {
        return songMap.size();
    }
    
}
