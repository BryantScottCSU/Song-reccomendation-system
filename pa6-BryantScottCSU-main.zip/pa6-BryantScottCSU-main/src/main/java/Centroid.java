import java.util.ArrayList;

public class Centroid {
    

    private double[] vector;
    private final ArrayList<Song> currentCluster;


    public Centroid(Song song) {
         vector = EuclideanCalc.getArray(song);
         currentCluster = new ArrayList<>();
         currentCluster.add(song);
    }

    public void setVector(double[] vector) {
        this.vector = vector;
    }

    public double[] getVector() {
        return vector;
    }

    public ArrayList<Song> getCluster() {
        return currentCluster;
    }

    public void addToCluster(Song song) {
        currentCluster.add(song);
    }

    public void clearCluster() {
        currentCluster.clear();
    }

    public boolean clusterHasSong(Song song) {
        return currentCluster.contains(song);
    }

}
