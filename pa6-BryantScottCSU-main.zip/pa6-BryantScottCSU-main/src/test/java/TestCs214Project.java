import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

public class TestCs214Project {

    @TempDir Path tmp;




    @Test
    public void pathThreeTest() throws Exception{

        reset();
        Path input  = tmp.resolve("testRatings.csv");
        Path output = tmp.resolve("testOutput.csv");

        String testcsv = """
                         song1,user1,5
                         song2,user1,3
                         song1,user2,2
                         song2,user2,4
                         """;
        Files.writeString(input, testcsv);

        SongSimilarityPath.pathThree(input.toString(), output.toString(), "-u");

        assertTrue(Files.exists(output));
        String text = Files.readString(output);
        assertTrue(text.contains("song1,song2,2.8284271247461903"));

    }
    @Test
    public void userNameTest() {
        User jack = new User("Jack");
        assertEquals("Jack", jack.getName());
    }

    @Test
    public void isDelinquent() {
        User user1 = new User("John");
        assertEquals(true, user1.isDelinquent());
    }

    @Test
    public void isDelinquent2() {
       
    }

    @Test
    public void userRatedSongsSize() {
        
    }

    public void userRatingTest() throws Exception { 

       
        
    }


    @Test
    public void pathOneTest() throws Exception {

        reset();
        SongStatsPath.pathOne("database/files/file1.csv", "database/files/output1.csv");
        assertEquals(1.0897247358851685, SongRepository.getInstance().getSongByName("song1").getStandardDiv());
        
        
    }

    @Test
    public void pathTwoTest() throws Exception {
       
        reset();
        Path input  = tmp.resolve("testRatings.csv");
        Path output = tmp.resolve("testOutput.csv");

        String testcsv = """
                         song1,user1,5
                         song2,user1,3
                         song1,user2,2
                         song2,user2,4
                         """;
        Files.writeString(input, testcsv);

        UserStatsPath.pathTwo(input.toString(), output.toString(), "-a");

        assertTrue(Files.exists(output));
        String text = Files.readString(output);
        assertTrue(text.contains("user1,song1,5"));
    }

    @Test
    public void testSong() throws Exception {
    }

    @Test
    public void testSongRepository() throws Exception {

        SongRepository.getInstance().addSong("Starships");
        Song testSong = SongRepository.getInstance().getSongByName("Starships");
        assertEquals("Starships", testSong.getName());
        assertEquals(true, SongRepository.getInstance().hasSong("Starships"));

    }

    @Test
void userRatedSongNames_direct() {

}

    @Test
    void badInput1() throws Exception{
        assertThrows(IOException.class, () ->
            SongStatsPath.pathOne("no/such/file.csv", "out.csv")
        );
        assertThrows(IOException.class, () ->
            UserStatsPath.pathTwo("no/such/file.csv", "out.csv", "-a")
        );
        assertThrows(IOException.class, () ->
           SongSimilarityPath.pathThree("no/such/file.csv", "out.csv", "-u")
        );
        assertThrows(IOException.class, () ->
           RatingPredictionPath.pathFour("no/such/file.csv", "out.csv", "-p")
        );
    }

        @Test
    void badInput2() throws Exception{
        assertThrows(IOException.class, () ->
            SongStatsPath.pathOne("database/files/file1.txt", "database/files/output.csv")
        );
        assertThrows(IOException.class, () ->
            UserStatsPath.pathTwo("database/files/file1.txt", "database/files/output.csv", "-a")
        );     
        assertThrows(IOException.class, () ->
            SongSimilarityPath.pathThree("database/files/file1.txt", "database/files/output.csv", "-u")
        ); 
        assertThrows(IOException.class, () ->
            RatingPredictionPath.pathFour("database/files/file1.txt", "database/files/output.csv", "-p")
        );    
    }

    @Test
    void badInput3() throws Exception{
        assertThrows(FileNotFoundException.class, () ->
            SongStatsPath.pathOne("database/files/file1.csv", "database/file/output.csv")
        );
        assertThrows(FileNotFoundException.class, () ->
            UserStatsPath.pathTwo("database/files/file1.csv", "database/file/outpt.csv", "-a")
        ); 
        assertThrows(FileNotFoundException.class, () ->
            SongSimilarityPath.pathThree("database/files/file1.txt", "database/files/output.csv", "-u")
        );      
        assertThrows(FileNotFoundException.class, () ->
            RatingPredictionPath.pathFour("database/files/file1.txt", "database/files/output.csv", "-p")
        );  
    }
    
    
    @Test
    void tooLowPredictedRating() throws Exception{
 
                reset();
        Path input  = tmp.resolve("testRatings.csv");
        Path output = tmp.resolve("testOutput.csv");

        String testcsv = """
song1,user1,1
song2,user1,5
song1,user2,1
song2,user2,2
song3,user2,1
song4,user1,1
                         """;
        Files.writeString(input, testcsv);

        RatingPredictionPath.pathFour(input.toString(), output.toString(), "-p");

        assertTrue(Files.exists(output));
        String text = Files.readString(output);
        String expected = """
song,user,predicted rating
song3,user1,1
song4,user2,1
                """;
        
            assertEquals(expected, text);


    }

    @Test
    void normalPredictedRating() throws Exception{
        reset();
        Path input  = tmp.resolve("testRatings.csv");
        Path output = tmp.resolve("testOutput.csv");

        String testcsv = """
song1,user1,2
song2,user1,3
song4,user1,4
song1,user2,2
song2,user2,3
song4,user2,5
song1,user3,4
song3,user3,5
song4,user3,4
song5,user3,5
song1,user4,1
song3,user4,2
song4,user4,1
song5,user5,3
song6,user5,2
                         """;
        Files.writeString(input, testcsv);

        RatingPredictionPath.pathFour(input.toString(), output.toString(), "-p");

        assertTrue(Files.exists(output));
        String text = Files.readString(output);
        String expected = """
song,user,predicted rating
song1,user5,2
song2,user3,5
song2,user4,1
song2,user5,NaN
song3,user1,4
song3,user2,5
song3,user5,3
song4,user5,2
song5,user1,4
song5,user2,5
song5,user4,2
song6,user1,NaN
song6,user2,NaN
song6,user3,4
song6,user4,NaN
                """;
        
            assertEquals(expected, text);

    }

        @Test
    void tooHighPredictedRating() throws Exception{
 
                reset();
        Path input  = tmp.resolve("testRatings.csv");
        Path output = tmp.resolve("testOutput.csv");

        String testcsv = """
song1,user1,2
song2,user1,3
song3,user1,5
song1,user2,2
song2,user2,5
song4,user2,5
                         """;
        Files.writeString(input, testcsv);

        RatingPredictionPath.pathFour(input.toString(), output.toString(), "-p");

        assertTrue(Files.exists(output));
        String text = Files.readString(output);
        String expected = """
song,user,predicted rating
song3,user2,5
song4,user1,4
                """;
        
            assertEquals(expected, text);


    }

        @BeforeEach
        void reset() {
            UserRepository.getInstance().clearForTests();
            SongRepository.getInstance().clearForTests();
            ListsRepository.getInstance().clearForTests(); 
        }



}