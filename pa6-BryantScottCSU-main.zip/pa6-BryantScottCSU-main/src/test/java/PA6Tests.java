import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;


public class PA6Tests {
    
    @TempDir Path tmp;


    @Test
    void KMeansCorrectnessTest() throws Exception{
        reset();
        Path input  = tmp.resolve("rock.csv");
        Path output = tmp.resolve("playlist.csv");
        String arg0 = input.toString() + "," + output.toString() + "," + "1";

        String testcsv = """
Bohemian Rhapsody,user1,5
Bohemian Rhapsody,user2,4
Bohemian Rhapsody,user3,5
Stairway to Heaven,user1,5
Stairway to Heaven,user2,4
Stairway to Heaven,user3,5
Hotel California,user1,5
Hotel California,user2,4
Hotel California,user3,3
November Rain,user1,1
November Rain,user2,5
November Rain,user3,1
                         """;
        Files.writeString(input, testcsv);
        
        ArrayList<String> toPass = new ArrayList<>();
        toPass.add("Bohemian Rhapsody");
        

        AlbumPath.pathSix(arg0, "-r", toPass);


        String text = Files.readString(output);
        String expected = """
Stairway to Heaven
Hotel California
November Rain
                """;

            
        assertEquals(fixString(expected), fixString(text));
            
    }

    private static String fixString(String s) {

        s =  s.replace("\r\n", "\n").replace("\r", "\n").replaceAll("[ \t]+\n", "\n").stripTrailing(); 
        return s;
    }

    @BeforeEach
        void reset() {
            UserRepository.getInstance().clearForTests();
            SongRepository.getInstance().clearForTests();
            ListsRepository.getInstance().clearForTests(); 
        }
}


