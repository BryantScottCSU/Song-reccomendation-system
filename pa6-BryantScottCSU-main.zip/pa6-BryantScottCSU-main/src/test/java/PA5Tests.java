import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;


public class PA5Tests {
    
    @TempDir Path tmp;

    @Test
    void normalPredictedRating() throws Exception{
        reset();
        Path input  = tmp.resolve("testRatings.csv");
        Path output = tmp.resolve("testOutput.csv");
        String arg0 = input.toString() + "," + output.toString();

        String testcsv = """
song1,user1,2
song2,user1,3
song4,user1,4
song1,user2,2
song2,user2,3
song4,user2,5
song1,user3,4
song3,user3,5
song4,user3,4
song5,user3,5
song1,user4,1
song3,user4,2
song4,user4,1
song5,user5,3
song6,user5,2
                         """;
        Files.writeString(input, testcsv);
        
        ArrayList<String> toPass = new ArrayList<>();
        toPass.add("song2");
        toPass.add("song3");
        toPass.add("song4");

        SongRecomendationPath.pathFive(arg0, "-r", toPass);

        
        Song song2 = SongRepository.getInstance().getSongByName("song2");
        Song song6 = SongRepository.getInstance().getSongByName("song6");
        User user1 = UserRepository.getInstance().getUserByName("user1");
        User user2 = UserRepository.getInstance().getUserByName("user2");
        User user4 = UserRepository.getInstance().getUserByName("user4");
        User user5 = UserRepository.getInstance().getUserByName("user5");
        assertEquals(3, user1.getPredictedRatingsMap().get(song6));
        assertEquals(3, user2.getPredictedRatingsMap().get(song6));
        assertEquals(2, user4.getPredictedRatingsMap().get(song6));
        assertEquals(3, user5.getPredictedRatingsMap().get(song2));

    }


    @Test
    void KMeansCorrectnessTest() throws Exception{
        reset();
        Path input  = tmp.resolve("testRatings.csv");
        Path output = tmp.resolve("testOutput.csv");
        String arg0 = input.toString() + "," + output.toString();

        String testcsv = """
song1,user1,5
song2,user1,3
song3,user1,2
song4,user1,4
song5,user1,3
song6,user1,4
song7,user1,1
song8,user1,5
song9,user1,2
song1,user2,3
song2,user2,5
song3,user2,3
song4,user2,4
song5,user2,4
song6,user2,4
song7,user2,4
song8,user2,4
song9,user2,2
song1,user3,2
song2,user3,5
song3,user3,5
song4,user3,4
song5,user3,2
song6,user3,1
song7,user3,1
song8,user3,3
song9,user3,2
song1,user4,2
song2,user4,1
song3,user4,5
song4,user4,3
song5,user4,5
song6,user4,5
song7,user4,5
song8,user4,1
song9,user4,4
song1,user5,4
song2,user5,2
song3,user5,3
song4,user5,1
song5,user5,3
song6,user5,5
song7,user5,2
song8,user5,1
song9,user5,5
                         """;
        Files.writeString(input, testcsv);
        
        ArrayList<String> toPass = new ArrayList<>();
        toPass.add("song1");
        toPass.add("song2");
        toPass.add("song3");

        SongRecomendationPath.pathFive(arg0, "-r", toPass);


        String text = Files.readString(output);
        String expected = """
user choice,recommendation
song1,song6
song2,song4
song2,song8
song3,song5
song3,song7
song3,song9
                """;
        
            assertEquals(expected, text);
    }

    @BeforeEach
        void reset() {
            UserRepository.getInstance().clearForTests();
            SongRepository.getInstance().clearForTests();
            ListsRepository.getInstance().clearForTests(); 
        }
}


